How to use Scripted Attack CSV FILES?

You can add your scripted files simply adding new text files with extension ".csv" in this folder.
When bot is started it will read csv files list and populate combo fields with new scripted attack algorithms available.
 
The fastest method to create new scripted files it is to duplicate an existing script and edit with a txt editor 
like Windows OS NotePad, or Free ware program NotePad++.

If you want detailed information about how to create and edit scripted attack CSV files, please visit MyBot.run forums:
https://mybot.run/forums/index.php?/topic/13503-guide-making-attack-csv-files/

MyBot.run forums also have entire forum section for discussion of community created attack CSV scripts.
https://mybot.run/forums/index.php?/forum/76-csv-attack-files/

You will find special subsections where you can request scripts, request help developing new attack plans, or share your new scripts.

Thanks for supporting your MyBot.run community!

