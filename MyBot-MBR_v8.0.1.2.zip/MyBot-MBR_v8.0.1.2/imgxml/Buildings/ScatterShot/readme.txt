Scattershots images are animated.  The animation is different depending on the location of the unit - TR, TL, BR and BL.  Each location has 2 animations so 8 possible images per level of scattershot.

TR _1 _2
TL _3 _4
BR _5 _6
BL _7 _8
